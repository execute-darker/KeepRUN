# KeepRUN

Keep the all application tasks in the background. 
将所有应用程序任务保留在后台. 

![GNU GPL-3.0 License](https://img.shields.io/badge/license-GNU%20GPL--3.0-%23A32D2B?style=flat-square&link=https%3A%2F%2Fwww.gnu.org%2Flicenses%2Fgpl-3.0.en.html)

### Author

[x.com/@execute_darker](https://x.com/execute_darker)

### Copyright

Licensed under GNU GPL-3.0, see [license](https://www.gnu.org/licenses/gpl-3.0.en.html)

<img src="https://www.gnu.org/graphics/heckert_gnu.transp.small.png" width="5%">

### Reference project

 - [lmkd](https://source.android.com/docs/core/perf/lmkd)
 - [lmkd hook](https://github.com/shadow3aaa/lmkd_hook)

### Acknowledgements

- [HamJin](https://jintaiyang123.org)
- [shadow3](https://github.com/shadow3aaa)
- [kuanglinfei](https://github.com/helloklf)